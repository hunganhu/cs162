Intel 80386 Programmer's Reference Manual HTML translation -- 0.9 version

I translated this document in html format because I think it is a good
source of information, and it seemed to me that its original .txt format
wasn't very handy to consult.
In addiction I thought it would have been a useful way to practice
unix shell programming.
I produced these files with bash, awk, sed under Linux, and a bit of
C to build the figures.
If you are interested in something concerning the way all this has been
done, drop me a line.

I produced most of this stuff with automatic, "ad hoc" tools, but it has
been necessary a lot of human "debugging". Still, I'm sure that there is
some particular to refine.
I'll be grateful to everyone that will send to me a beta-report.

A lot of inter-page linking has to be done again, but maybe it is better
to wait for a definitively "error free" version.

DISCLAIMER
I hope that giving this work in the public domain do not break any national or
international copyright law. But if someone thinks, or knows that 
distributing this hypertext is forbidden by some applicable law, please, 
tell me.

Luigi Sgro
via Shelley 7/9           Phone: ++39 10 3772118
16148 Genova, ITALY       e-mail: gigio@mc.village.it 

Below, there is the original disclaimer published by Intel with the manual.

INTEL 80386 PROGRAMMER'S REFERENCE MANUAL 1986

Intel Corporation makes no warranty for the use of its products and
assumes no responsibility for any errors which may appear in this document
nor does it make a commitment to update the information contained herein.

Intel retains the right to make changes to these specifications at any
time, without notice.

Contact your local sales office to obtain the latest specifications before
placing your order.

The following are trademarks of Intel Corporation and may only be used to
identify Intel Products:

Above, BITBUS, COMMputer, CREDIT, Data Pipeline, FASTPATH, Genius, i, �,
ICE, iCEL, iCS, iDBP, iDIS, I�ICE, iLBX, im, iMDDX, iMMX, Inboard,
Insite, Intel, intel, intelBOS, Intel Certified, Intelevision,
inteligent Identifier, inteligent Programming, Intellec, Intellink,
iOSP, iPDS, iPSC, iRMK, iRMX, iSBC, iSBX, iSDM, iSXM, KEPROM, Library
Manager, MAPNET, MCS, Megachassis, MICROMAINFRAME, MULTIBUS, MULTICHANNEL,
MULTIMODULE, MultiSERVER, ONCE, OpenNET, OTP, PC BUBBLE, Plug-A-Bubble,
PROMPT, Promware, QUEST, QueX, Quick-Pulse Programming, Ripplemode, RMX/80,
RUPI, Seamless, SLD, SugarCube, SupportNET, UPI, and VLSiCEL, and the
combination of ICE, iCS, iRMX, iSBC, iSBX, iSXM, MCS, or UPI and a numerical
suffix, 4-SITE.

MDS is an ordering code only and is not used as a product name or
trademark. MDS(R) is a registered trademark of Mohawk Data Sciences
Corporation.

Additional copies of this manual or other Intel literature may be obtained
from:

Intel Corporation
Literature Distribution
Mail Stop SC6-59
3065 Bowers Avenue
Santa Clara, CA 95051

(c)INTEL CORPORATION 1987    CG-5/26/87

